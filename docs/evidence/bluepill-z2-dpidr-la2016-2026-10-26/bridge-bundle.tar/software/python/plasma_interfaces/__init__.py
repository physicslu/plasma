"""Minimal isolated package for the Blue Pill PS proof."""
