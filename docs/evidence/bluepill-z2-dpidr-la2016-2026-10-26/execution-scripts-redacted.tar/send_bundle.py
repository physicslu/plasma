import hashlib
import json
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
bundle = here / 'bridge-bundle.tar'
digest = hashlib.sha256(bundle.read_bytes()).hexdigest()
remote_path = '/tmp/plasma-bluepill-bridge-' + digest[:12] + '.tar'
login = json.loads((Path.home() / '.config/plasma/z2-login-smoke.json').read_text())
host = login['ssh_username'] + '@' + login['ssh_host']
common = ['-F', '/dev/null', '-i', str(Path.home() / '.ssh/plasma_z2_ed25519'),
          '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes',
          '-o', 'StrictHostKeyChecking=yes',
          '-o', 'UserKnownHostsFile=' + str(Path.home() / '.ssh/known_hosts'),
          '-o', 'ConnectTimeout=8']
check = subprocess.run(['ssh', *common, '--', host,
                        'test ! -e ' + remote_path], capture_output=True,
                       timeout=15)
if check.returncode:
    raise SystemExit('REMOTE_BUNDLE_PATH_EXISTS_OR_SSH_FAILED')
copy = subprocess.run(['scp', *common, '--', str(bundle),
                       host + ':' + remote_path], capture_output=True,
                      timeout=30)
if copy.returncode:
    raise SystemExit('SCP_FAILED')
verify = subprocess.run(['ssh', *common, '--', host,
                         'sha256sum ' + remote_path], capture_output=True,
                        text=True, timeout=15)
if verify.returncode or not verify.stdout.startswith(digest + ' '):
    raise SystemExit('REMOTE_BUNDLE_SHA_MISMATCH')
print(json.dumps({'remote_bundle': remote_path, 'sha256': digest,
                  'bytes': bundle.stat().st_size}, sort_keys=True))
