import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import threading
import time

here = Path(__file__).resolve().parent
output = here / 'bluepill-z2-dpidr-02.sr'
report = here / 'capture-report-02.json'
assert not output.exists() and not report.exists(), 'EVIDENCE_ALREADY_EXISTS'
app = Path('/opt/plasma/hil-tools/kingst-la2016-sigrok.AppImage')
firmware = Path('<SWPC_HOME>/.local/share/sigrok-firmware')
assert hashlib.sha256(app.read_bytes()).hexdigest() == 'b551cb26e8bd3261bb650fac98e62b70a6786f7f5521d62e86bc7e30cebf4475'
assert (firmware / 'kingst-la-01a2.fw').is_file()
matches = []
for entry in Path('/sys/bus/usb/devices').iterdir():
    try:
        if ((entry / 'idVendor').read_text().strip().lower(),
                (entry / 'idProduct').read_text().strip().lower()) != ('77a1', '01a2'):
            continue
        bus = int((entry / 'busnum').read_text())
        dev = int((entry / 'devnum').read_text())
        node = Path(f'/dev/bus/usb/{bus:03}/{dev:03}')
        assert stat.S_ISCHR(node.stat().st_mode) and os.access(node, os.R_OK | os.W_OK)
        matches.append((f'{bus}.{dev}', node))
    except (FileNotFoundError, PermissionError):
        continue
assert len(matches) == 1, 'LA_NOT_UNIQUE_OR_ACCESS_DENIED'
conn, node = matches[0]
with Path('/run/lock/plasma-la2016.lock').open('a+') as held:
    fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
    busy = subprocess.run(['fuser', '-s', str(node)], capture_output=True, timeout=4)
    assert busy.returncode == 1, 'LA_BUSY_OR_UNCERTAIN'
    env = os.environ.copy()
    env['SIGROK_FIRMWARE_PATH'] = str(firmware)
    cmd = [str(app), '--appimage-extract-and-run', '--loglevel', '3',
           '--driver', 'kingst-la2016:conn=' + conn,
           '--config', 'samplerate=5m', '--channels', 'CH0,CH1,CH2',
           '--samples', '50000000', '--output-file', str(output)]
    capture = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True,
                               bufsize=1, env=env)
    lines = []
    ready = threading.Event()
    def drain():
        assert capture.stdout is not None
        for line in capture.stdout:
            lines.append(line)
            if 'session: Starting.' in line:
                ready.set()
    thread = threading.Thread(target=drain, daemon=True)
    thread.start()
    remote_result = None
    started = time.time()
    if ready.wait(8) and capture.poll() is None:
        triggered = time.time()
        remote_result = subprocess.run(
            [sys.executable, str(here / 'remote.py'), str(here / 'run_dpidr.py')],
            capture_output=True, text=True, timeout=100)
    else:
        triggered = None
    try:
        capture_exit = capture.wait(timeout=20)
    except subprocess.TimeoutExpired:
        capture.terminate()
        capture_exit = capture.wait(timeout=5)
    thread.join(timeout=1)
    finished = time.time()
    data = {
        'capture_started_unix': started, 'dpidr_triggered_unix': triggered,
        'capture_finished_unix': finished,
        'capture_exit': capture_exit,
        'capture_log_tail': ''.join(lines)[-2500:],
        'capture_bytes': output.stat().st_size if output.is_file() else None,
        'capture_sha256': (hashlib.sha256(output.read_bytes()).hexdigest()
                           if output.is_file() else None),
        'remote_exit': remote_result.returncode if remote_result else None,
        'remote_stdout': remote_result.stdout[-8000:] if remote_result else '',
        'remote_stderr': remote_result.stderr[-1500:] if remote_result else '',
    }
    report.write_text(json.dumps(data, sort_keys=True, indent=2) + '\n')
print(json.dumps({'capture_exit': data['capture_exit'],
                  'capture_bytes': data['capture_bytes'],
                  'capture_sha256': data['capture_sha256'],
                  'remote_exit': data['remote_exit'],
                  'remote_stdout': data['remote_stdout'][-3500:]}, sort_keys=True))
raise SystemExit(0 if capture_exit == 0 and remote_result and
                 remote_result.returncode == 0 else 1)
