import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

app = Path('/opt/plasma/hil-tools/kingst-la2016-sigrok.AppImage')
firmware = Path('<SWPC_HOME>/.local/share/sigrok-firmware')
lock = Path('/run/lock/plasma-la2016.lock')
expected = 'b551cb26e8bd3261bb650fac98e62b70a6786f7f5521d62e86bc7e30cebf4475'
assert hashlib.sha256(app.read_bytes()).hexdigest() == expected, 'LA_APP_HASH'
assert (firmware / 'kingst-la-01a2.fw').is_file(), 'LA_FIRMWARE_MISSING'
matches = []
for entry in Path('/sys/bus/usb/devices').iterdir():
    try:
        if ((entry / 'idVendor').read_text().strip().lower(),
                (entry / 'idProduct').read_text().strip().lower()) != ('77a1', '01a2'):
            continue
        bus, dev = (int((entry / field).read_text())
                    for field in ('busnum', 'devnum'))
        node = Path(f'/dev/bus/usb/{bus:03}/{dev:03}')
        assert stat.S_ISCHR(node.stat().st_mode) and os.access(node, os.R_OK | os.W_OK)
        matches.append((f'{bus}.{dev}', node))
    except (FileNotFoundError, PermissionError):
        continue
assert len(matches) == 1, 'LA_NOT_UNIQUE_OR_ACCESS_DENIED'
conn, node = matches[0]
with lock.open('a+') as held:
    fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
    busy = subprocess.run(['fuser', '-s', str(node)], capture_output=True, timeout=4)
    assert busy.returncode == 1, 'LA_BUSY_OR_UNCERTAIN'
    env = os.environ.copy()
    env['SIGROK_FIRMWARE_PATH'] = str(firmware)
    command = [str(app), '--appimage-extract-and-run', '--driver',
               'kingst-la2016:conn=' + conn, '--show']
    result = subprocess.run(command, capture_output=True, text=True,
                            timeout=25, env=env)
print(json.dumps({'la_unique': True, 'usb_access': True,
                  'app_sha256': expected, 'firmware_present': True,
                  'show_exit': result.returncode,
                  'driver_initialized': result.returncode == 0 and
                  'kingst-la2016' in (result.stdout + result.stderr).lower()},
                 sort_keys=True))
raise SystemExit(result.returncode)
