import json
from pathlib import Path
import subprocess

binary = Path('/opt/plasma/programming-engines/openocd/0.12.0-5088db4c9154/bin/openocd')
config = ('adapter driver remote_bitbang; '
          'remote_bitbang host /run/plasma-bluepill-direct/swd.sock; '
          'remote_bitbang port 0; transport select swd; adapter speed 100; '
          'swd newdap bluepill cpu -expected-id 0x1ba01477; '
          'dap create bluepill.dap -chain-position bluepill.cpu; shutdown')
p = subprocess.run([str(binary), '-c', config], capture_output=True,
                   text=True, timeout=10)
print(json.dumps({'exit': p.returncode, 'output': (p.stdout + p.stderr)[-2000:]},
                 sort_keys=True))
raise SystemExit(p.returncode)
