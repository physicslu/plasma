import json
from pathlib import Path
import shutil
import subprocess

openocd = Path('/opt/plasma/programming-engines/openocd/0.12.0-5088db4c9154/bin/openocd')
result = {'gcc': shutil.which('gcc'), 'cc': shutil.which('cc'),
          'openocd_exists': openocd.is_file()}
if openocd.is_file():
    cmd = [str(openocd), '-c',
           'adapter driver remote_bitbang; transport select swd; shutdown']
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    result['remote_bitbang_swd_exit'] = p.returncode
    result['remote_bitbang_swd_output'] = (p.stdout + p.stderr)[-1800:]
print(json.dumps(result, sort_keys=True))
