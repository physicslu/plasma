import hashlib
import io
import json
from pathlib import Path
import tarfile

repo = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'bridge-bundle.tar'
files = (
    'scripts/bluepill-wordport-session.py',
    'software/python/plasma_interfaces/bluepill_remote_bitbang.py',
    'software/python/plasma_interfaces/bluepill_z2_word_port.py',
    'software/python/plasma_interfaces/fixed_abi_mmio_port.py',
    'software/python/plasma_interfaces/linux_mmio.py',
    'software/python/native/armv7_mmio_barrier.c',
)
hashes = {}
with tarfile.open(out, 'w') as bundle:
    for name in files:
        data = (repo / name).read_bytes()
        hashes[name] = hashlib.sha256(data).hexdigest()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        bundle.addfile(info, io.BytesIO(data))
    name = 'software/python/plasma_interfaces/__init__.py'
    data = b'"""Minimal isolated package for the Blue Pill PS proof."""\n'
    hashes[name] = hashlib.sha256(data).hexdigest()
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = 0o644
    bundle.addfile(info, io.BytesIO(data))
print(json.dumps({'tar_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'files': hashes}, sort_keys=True))
