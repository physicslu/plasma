import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

archive = Path('/tmp/plasma-bluepill-bridge-87ff32c79360.tar')
archive_sha = '87ff32c79360d57bc9abd7c9ecaf67a68be3cc6b7464cadfb43db589b8c9a8ff'
dest = Path('/opt/plasma/bluepill-direct-20261026')
expected = {
    'scripts/bluepill-wordport-session.py': 'cae723fc1027ef9a43f106aed70134ef0638dce78d9e56977c8b8e233712f0b9',
    'software/python/native/armv7_mmio_barrier.c': '6e44d47990d9bc4f8d27c954cd2342ab82c4c35e48913f68f94b4329c4266fe0',
    'software/python/plasma_interfaces/__init__.py': '7f8c3452a28080ecaf11b3ab5712d3eef041c54b2098c374c16860e59209c24d',
    'software/python/plasma_interfaces/bluepill_remote_bitbang.py': '3870c6c74779d57a14c6e09769e3bad8e669a55ef2bd2b261227df1178128ef5',
    'software/python/plasma_interfaces/bluepill_z2_word_port.py': 'a40a474c1ed0f8d1797ced09bbe408364bbc21664722ff508eb312f92bd4d7c0',
    'software/python/plasma_interfaces/fixed_abi_mmio_port.py': '0f6b819377a99b773838371d32e9dc47bb033dc4f1f7ba39ba062904f4a452c1',
    'software/python/plasma_interfaces/linux_mmio.py': '0c9275e171bb83aa084802046ebca07495eba90d9815789ec95b2e26f66c6582',
}
assert hashlib.sha256(archive.read_bytes()).hexdigest() == archive_sha, 'ARCHIVE_SHA'
assert not dest.exists(), 'DEST_ALREADY_EXISTS'
contents = {}
with tarfile.open(archive, 'r') as bundle:
    members = bundle.getmembers()
    assert {m.name for m in members} == set(expected), 'ARCHIVE_MEMBERS'
    for member in members:
        assert member.isfile() and not member.issym() and member.size < 100000, 'ARCHIVE_TYPE'
        data = bundle.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest() == expected[member.name], 'MEMBER_SHA'
        contents[member.name] = data
dest.mkdir(mode=0o700)
for name, data in contents.items():
    path = dest / name
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open('xb') as stream:
        stream.write(data)
    path.chmod(0o644)
source = dest / 'software/python/native/armv7_mmio_barrier.c'
library = dest / 'software/python/native/libplasma_mmio_barrier.so'
subprocess.run(['cc', '-O2', '-march=armv7-a', '-marm', '-mfpu=vfpv3',
                '-mfloat-abi=hard', '-fPIC', '-shared', '-o', str(library),
                str(source)], check=True, capture_output=True, timeout=20)
header = subprocess.run(['readelf', '-h', str(library)], check=True,
                        capture_output=True, text=True, timeout=5).stdout
asm = subprocess.run(['objdump', '-d', str(library)], check=True,
                     capture_output=True, text=True, timeout=5).stdout
assert 'ELF32' in header and 'ARM' in header and len(re.findall(r'\bdmb\s+sy\b', asm)) == 1, 'BARRIER_ELF_OR_DMB'
sys.path.insert(0, str(dest / 'software/python'))
from plasma_interfaces.fixed_abi_mmio_port import ARMv7DMBBarrier
from plasma_interfaces.bluepill_z2_word_port import BluepillZ2WordPort
from plasma_interfaces.bluepill_remote_bitbang import RemoteBitbangSWD
digest = hashlib.sha256(library.read_bytes()).hexdigest()
ARMv7DMBBarrier(str(library), sha256=digest)()
print(json.dumps({'result': 'STAGED', 'path': str(dest), 'archive_sha256': archive_sha,
                  'barrier_sha256': digest, 'modules_imported': True}, sort_keys=True))
