import json
from pathlib import Path
import time

root = Path('/root/plasma-path2-approved')
result = []
for path in root.rglob('*'):
    if path.is_file() and path.suffix in ('.pyc', '.pyo'):
        s = path.lstat()
        result.append({'relative': str(path.relative_to(root)),
                       'bytes': s.st_size, 'owner_uid': s.st_uid,
                       'mtime_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ',
                                                  time.gmtime(s.st_mtime))})
print(json.dumps({'bytecode': result}, sort_keys=True))
