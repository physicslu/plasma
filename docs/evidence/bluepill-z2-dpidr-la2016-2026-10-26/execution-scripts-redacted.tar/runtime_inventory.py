import hashlib
import json
from pathlib import Path
import subprocess

roots = [Path('/opt/plasma'), Path('/root/plasma-path2-approved')]
names = {'bluepill-wordport-session.py', 'bluepill_remote_bitbang.py',
         'bluepill_z2_word_port.py', 'libplasma_mmio_barrier.so'}
found = []
for root in roots:
    if root.is_dir():
        for path in root.rglob('*'):
            if path.name in names and path.is_file():
                h = hashlib.sha256(path.read_bytes()).hexdigest()
                found.append({'path': str(path), 'sha256': h})
binary = Path('/opt/plasma/programming-engines/openocd/0.12.0-9ea7f3d647c8/bin/openocd')
version = subprocess.run([str(binary), '--version'], capture_output=True,
                         text=True, timeout=8) if binary.is_file() else None
services = {}
for service in ('plasma-server', 'plasma-web', 'plasma-bootstrap',
                'plasma-runtime-activation'):
    p = subprocess.run(['systemctl', 'is-active', service], capture_output=True,
                       text=True, timeout=3)
    services[service] = p.stdout.strip() or 'unknown'
result = {'files': found, 'openocd_version':
          (version.stdout + version.stderr).strip() if version else None,
          'services': services}
print(json.dumps(result, sort_keys=True))
