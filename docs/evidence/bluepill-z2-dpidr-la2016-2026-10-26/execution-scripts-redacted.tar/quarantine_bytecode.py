import hashlib
import json
from pathlib import Path
import shutil

root = Path('/root/plasma-path2-approved')
quarantine = Path('/root/plasma-path2-bytecode-quarantine-20261026')
names = (
    'pl/hil/__pycache__/fpga_image_root.cpython-310.pyc',
    'pl/hil/__pycache__/fpga_image_guard.cpython-310.pyc',
    'pl/hil/__pycache__/fpga_image_admission.cpython-310.pyc',
)
assert not quarantine.exists(), 'QUARANTINE_EXISTS'
found = {str(p.relative_to(root)) for p in root.rglob('*.pyc')}
assert found == set(names), 'BYTECODE_SET_CHANGED'
quarantine.mkdir(mode=0o700)
receipts = {}
for name in names:
    source = root / name
    assert source.is_file() and not source.is_symlink(), 'SOURCE_CHANGED'
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    target = quarantine / name
    target.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    source.rename(target)
    assert hashlib.sha256(target.read_bytes()).hexdigest() == digest, 'MOVED_SHA_CHANGED'
    receipts[name] = digest
assert not any(root.rglob('*.pyc')), 'BYTECODE_REMAINS'
print(json.dumps({'result': 'QUARANTINED', 'files': receipts,
                  'quarantine': str(quarantine)}, sort_keys=True))
