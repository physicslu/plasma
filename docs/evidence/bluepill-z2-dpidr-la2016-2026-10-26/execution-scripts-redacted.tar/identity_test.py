import json
from pathlib import Path
import subprocess

pin = Path('/root/plasma-path2-approved/.plasma-path2-source-commit').read_text().strip()
assert pin == '55f6db3bc5fa866135e5a9070175928d044e53ce', 'ROOT_PIN_CHANGED'
cmd = ['/usr/local/libexec/plasma/z2-path2-root-entry', 'test', pin]
p = subprocess.run(cmd, capture_output=True, text=True, timeout=55)
print(json.dumps({'exit': p.returncode, 'stdout': p.stdout[-3500:],
                  'stderr': p.stderr[-500:]}, sort_keys=True))
raise SystemExit(p.returncode)
