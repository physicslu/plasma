import hashlib
import json
from pathlib import Path
import subprocess


def sha(path):
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


firmware = Path('/lib/firmware')
protected = Path('/root/plasma-path2-approved')
state = protected / '.plasma-fpga-image-deployment-state.json'
manifest = firmware / 'plasma-image-manifest.json'
manager = Path('/sys/class/fpga_manager/fpga0')
result = {
    'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
    'manager_state': (manager / 'state').read_text().strip(),
    'manifest_sha256': sha(manifest),
    'manifest': json.loads(manifest.read_text()) if manifest.is_file() else None,
    'candidate_sha256': sha(firmware / 'plasma-bluepill-swd-65dca783.bin'),
    'golden_sha256': sha(firmware / 'base.bin'),
    'source_pin': (protected / '.plasma-path2-source-commit').read_text().strip()
        if (protected / '.plasma-path2-source-commit').is_file() else None,
    'root_entry_installed': Path('/usr/local/libexec/plasma/z2-path2-root-entry').is_file(),
    'checkpoint': json.loads(state.read_text()) if state.is_file() else None,
    'openocd_binaries': [str(p) for root in (
        Path('/opt/plasma/programming-engines/openocd'), Path('/usr/local/bin'))
        if root.is_dir() for p in root.rglob('openocd') if p.is_file()][:12],
}
log = subprocess.run(['dmesg', '--color=never'], capture_output=True,
                     text=True, check=True, timeout=10).stdout
loads = [line for line in log.splitlines()
         if 'fpga_manager fpga0: writing ' in line]
result['manager_last_load'] = loads[-1] if loads else None
for node in ('/dev/mem', '/dev/uio1'):
    check = subprocess.run(['fuser', '-v', node], capture_output=True,
                           text=True, timeout=4)
    result['fuser_' + Path(node).name] = {
        'exit': check.returncode,
        'busy': check.returncode == 0,
    }
print(json.dumps(result, sort_keys=True))
